//Press the mouse and the letter will rotate
//Remember to turn on your sound!!

let points;
let font;
let shapeBaseSize = 25;
let letterCenter;    
let rotationAngle = 0; 
let isRotating = false;
let playSong = false;
function preload() {
  font = loadFont('FearFluid-Regular.ttf'); 
  song = loadSound('FunkyTown.mp3');
}

function setup() {
  createCanvas(430, 430, WEBGL);
  colorMode(HSB, 360, 100, 100, 100);
  points = getPoints('A');
  let bounds = getBounds(points);
  letterCenter = createVector((bounds.minX + bounds.maxX) / 2, (bounds.minY + bounds.maxY) / 2);
}

function draw() {
  background(0, 0, 95);

  if (isRotating) {
    rotationAngle += 0.05; 
  }
  
  push();
    // Apply the cumulative rotation along the Y-axis.
    rotateY(rotationAngle);
    drawTypeface();
  pop();
}

function drawTypeface() {
  noStroke();
  push();
    // Translate so the letter's computed center is at the canvas center.
    translate(-letterCenter.x, -letterCenter.y);
    
    // Loop through each point of the letter 
    for (let i = 0; i < points.length; i++) {
      push();
        let x = points[i].x;
        let y = points[i].y;
        
        let dx = sin(frameCount * 0.03 + i * 0.05) * 8;
        let dy = cos(frameCount * 0.03 + i * 0.05) * 8;
        translate(x + dx, y + dy);
        
        rotateX(frameCount * 0.01 + i * 0.02);
        rotateZ(frameCount * 0.02 + i * 0.03);
        
        let dynamicSize = shapeBaseSize + 5 * sin(frameCount * 0.02 + i);
        
        let hueVal = (frameCount * 0.5 + i * 2) % 360;
        fill(hueVal, 80, 100, 80);
        
        ellipsoid(dynamicSize/2, (dynamicSize * 1.5)/2, dynamicSize/2);
      pop();
    }
  pop();
}

// Returns the points for a given letter using textToPoints()
function getPoints(letter) {
  return font.textToPoints(letter, 0, 0, 300, {
    sampleFactor: 0.1,
    simplifyThreshold: 0
  });
}

// Computes the bounding box for an array of points
function getBounds(pts) {
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (let p of pts) {
    if (p.x < minX) minX = p.x;
    if (p.x > maxX) maxX = p.x;
    if (p.y < minY) minY = p.y;
    if (p.y > maxY) maxY = p.y;
  }
  return { minX, maxX, minY, maxY };
}

//rotate and play or pause song on each mouse press.
function mousePressed() {
  isRotating = !isRotating;
  playSong = !playSong;
  if (playSong) {
    song.play();
  } else {
    song.pause();
  }
}

function keyPressed() {
  points = getPoints(String.fromCharCode(keyCode));
  let bounds = getBounds(points);
  letterCenter = createVector((bounds.minX + bounds.maxX) / 2, (bounds.minY + bounds.maxY) / 2);
}
