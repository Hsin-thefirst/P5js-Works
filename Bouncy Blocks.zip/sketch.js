// Load Matter.js modules
var Engine = Matter.Engine,
    Runner = Matter.Runner,
    Bodies = Matter.Bodies,
    World = Matter.World;

var engine, world;
var container = []; // Array to hold Box objects
var ground;

function setup() {
  createCanvas(400, 400);
  engine = Engine.create();
  world = engine.world;
  
  // Create a ground
  ground = Bodies.rectangle(200, 390, 400, 20, { isStatic: true });
  World.add(world, ground);
}

function mousePressed() {
  // Create a new Box at the mouse location
  container.push(new Box(mouseX, mouseY, 20, 50));
}

function draw() {
  background(220,20);
  
  // Manually update the physics engine
  Engine.update(engine);
  
  // Draw each box
  for (var i = 0; i < container.length; i++) {
    container[i].show();
  }
  
  // Draw the ground 
  fill(100);
  rectMode(CENTER);
  rect(ground.position.x, ground.position.y, 400, 20);
}

function Box(x, y, w, h) {
  var option = {
    friction : 1,
    restitution: 1.5
  }
  this.w = w;
  this.h = h;
  // Create a Matter.js body for this box and add it to the world
  this.body = Bodies.rectangle(x, y, w, h, option);
  World.add(world, this.body);
  
  this.show = function() {
    var pos = this.body.position;
    var angle = this.body.angle;
    push();
    translate(pos.x, pos.y);
    rotate(angle);
    rectMode(CENTER);
    fill(255);
    rect(0, 0, this.w, this.h);
    pop();
  }
}
